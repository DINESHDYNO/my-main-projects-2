import 'package:demo_project/constant/Constant.dart';
import 'package:flutter/material.dart';

import '../member_page_screens/Full_Profile.dart';
import '../member_page_screens/SearchPage.dart';


class MemberPage extends StatefulWidget {
  const MemberPage({super.key});

  @override
  State<MemberPage> createState() => _MemberPageState();
}

class _MemberPageState extends State<MemberPage> {
  @override
  Widget build(BuildContext context) {
    Size size=MediaQuery.of(context).size;
    return  SafeArea(
      child: Scaffold(
        backgroundColor:const Color(0xFFFFF9F0),
        body: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                height: 64,
                decoration: BoxDecoration(
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.2),
                      spreadRadius: 3,
                      blurRadius: 8,
                      offset: const Offset(3, 3),
                    ),
                  ],
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Image.asset('assets/images/16.png',),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        GestureDetector(
                          onTap: () {
                            _displayBottomSheet(context);
                          },
                          child: Image.asset('assets/images/20.png', scale: 3),
                        ),
                        const SizedBox(width: 10),
                        Image.asset('assets/images/17.png', scale: 3),
                      ],
                    )
                  ],
                ),
              ),
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
                height: size.height * 0.6,
                width: size.width,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  image: const DecorationImage(
                    image: AssetImage("assets/images/63.png"),
                    fit: BoxFit.cover,
                  ),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      bottom: 5,
                      left: 5,
                      right: 5,
                      child: Container(
                        padding: const EdgeInsets.all(5),
                        margin: const EdgeInsets.all(10),
                      //  height: size.height * 0.21,
                        decoration: BoxDecoration(
                          color: Colors.black45,
                          borderRadius: BorderRadius.circular(30),
                        ),
                        child: Stack(
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(20),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.symmetric(horizontal: 5),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Row(
                                          children: [
                                            const Text(
                                              'Ramya Kishnan',
                                              style: TextStyle(
                                                fontWeight: FontWeight.w700,
                                                color: Colors.white,
                                                fontSize: 20,
                                              ),
                                            ),
                                            const SizedBox(width: 5),
                                            Image.asset('assets/images/23.png', scale: 3),
                                          ],
                                        ),
                                        const Icon(Icons.more_vert, color: Colors.white),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(height: 10,),
                                  const Padding(
                                    padding: EdgeInsets.symmetric(horizontal: 5),
                                    child: Text(
                                      'Member ID : AE12345',
                                      style: TextStyle(color: Colors.white, fontSize: 14),
                                    ),
                                  ),
                                  const SizedBox(height: 10,),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Image.asset("assets/images/18.png", scale: 3.5),
                                      const SizedBox(width: 5),
                                      const Text(
                                        '23 yrs,5 Ft',
                                        style: TextStyle(color: Colors.white, fontSize: 14),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 10,),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        children: [
                                          Image.asset("assets/images/19.png", scale: 3.5),
                                          const SizedBox(width: 5),
                                          const Text(
                                            'Chennai',
                                            style: TextStyle(color: Colors.white, fontSize: 14),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 5),
                                ],
                              ),
                            ),
                            Positioned(
                              bottom: 10,
                              right: 10,
                              child: ElevatedButton(
                                onPressed: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(builder: (context) => const FullProfilePage()),
                                  );
                                },
                                style: ElevatedButton.styleFrom(
                                  padding: EdgeInsets.zero,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(100),
                                    side: const BorderSide(
                                      color: Colors.white,
                                      width: 1.0,
                                    ),
                                  ),
                                  elevation: 0,
                                  primary: Colors.black38,
                                ),
                                child: const Padding(
                                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                                  child: Text('Full Profile',style: TextStyle(fontSize: 14),),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 10,),
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 20),
                padding: const EdgeInsets.all(5),
                decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.3),
                        spreadRadius: 3,
                        blurRadius: 8,
                        offset: const Offset(3, 3),
                      ),
                    ],
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(50)
                ),child: Center(
                  child: ListTile(
                  leading: Container(
                    height: 44,
                    width: 44,
                    decoration: BoxDecoration(
                        color: const Color(0xFFf0f0f0),
                      borderRadius: BorderRadius.circular(50)
                  ),child: Image.asset('assets/images/21.png',scale: 4,)
              ),
                  trailing: Container(
                    height: 44,
                    width: 44,
                    decoration: BoxDecoration(
                        color: const Color(0xFFf0f0f0),
                        borderRadius: BorderRadius.circular(50)
                    ),child: Image.asset('assets/images/22.png',scale: 4,)
                  ),
                  title: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        height: 44,
                        width: 44,
                        decoration: BoxDecoration(
                            color: primaryColor,
                            borderRadius: BorderRadius.circular(50)
                        ),child: Image.asset('assets/images/24.png',scale: 3,)
                      ),
                      const SizedBox(width: 10,),
                      Container(
                        height: 44,
                        width: 44,
                        decoration: BoxDecoration(
                            color: primaryColor,
                            borderRadius: BorderRadius.circular(50)
                        ),child: Image.asset('assets/images/25.png',scale: 3,)
                      ),
                      const SizedBox(width: 10,),
                      Container(
                        height: 44,
                        width: 44,
                        decoration: BoxDecoration(
                            color: primaryColor,
                            borderRadius: BorderRadius.circular(50)
                        ),child: Image.asset('assets/images/26.png',scale: 3,)
                      ),
                    ],
                  ),
              ),
                )
              ),
            ],
          ),
        ),
      ),
    );
  }
  Future _displayBottomSheet(BuildContext context) async {
    Size size=MediaQuery.of(context).size;
    await showModalBottomSheet(
      barrierColor: Colors.black54,
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(30))),
      builder: (context) => SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Container(
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 20,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Image.asset("assets/images/34.png",scale: 2.2,),
                    const Text('Search',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 24),),
                  ],
                ),
                const SizedBox(height: 10,),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(10),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('Age From',style: TextStyle(fontWeight: FontWeight.bold,color: primaryColor,fontSize: 14),),
                              const SizedBox(height: 10,),
                              Container(
                                height: 60,
                                width: size.width/2.5,
                                decoration: BoxDecoration(
                                    color: Colors.grey.withOpacity(0.15),
                                    borderRadius: BorderRadius.circular(15)
                                ),child: Padding(
                                  padding: const EdgeInsets.symmetric(horizontal: 5),
                                  child: ListTile(
                                    title: TextFormField(
                                      decoration: const InputDecoration(
                                          hintText: "Enter Age",
                                          border: InputBorder.none
                                      ),
                                    ),
                                  )
                              ),
                              )
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(10),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('To',style: TextStyle(fontWeight: FontWeight.bold,color: primaryColor),),
                              const SizedBox(height: 10,),
                              Container(
                                height: 60,
                                width: size.width/2.5,
                                decoration: BoxDecoration(
                                    color: Colors.grey.withOpacity(0.15),
                                    borderRadius: BorderRadius.circular(15)
                                ),child: Padding(
                                  padding: const EdgeInsets.symmetric(horizontal: 5),
                                  child: ListTile(
                                    title: TextFormField(
                                      decoration: const InputDecoration(
                                          hintText: "Enter Age",
                                          border: InputBorder.none
                                      ),
                                    ),
                                  )
                              ),
                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                    const Padding(
                      padding: EdgeInsets.all(10),
                      child: Text("Religion",style: TextStyle(fontSize: 16,color: primaryColor),),
                    ),
                    Container(
                      margin: const EdgeInsets.symmetric(horizontal: 10),
                      height: 60,
                      width: size.width,
                      decoration: BoxDecoration(
                        color: Colors.grey.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20,vertical: 5),
                        child: DropdownButton(
                          underline: const SizedBox(),
                          icon: const Icon(Icons.arrow_drop_down),
                          isExpanded: true,
                          items: [
                          ],
                          onChanged: (value) {
                          },
                          hint: Text(
                            'Select',
                            style: TextStyle(color: Colors.grey[700]),
                          ),
                        ),
                      ),
                    ),
                    const Padding(
                      padding: EdgeInsets.all(10),
                      child: Text("Mother Tongue",style: TextStyle(fontSize: 16,color: primaryColor),),
                    ),
                    Container(
                      margin: const EdgeInsets.symmetric(horizontal: 10),
                      height: 60,
                      width: size.width,
                      decoration: BoxDecoration(
                        color: Colors.grey.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20,vertical: 5),
                        child: DropdownButton(
                          underline: const SizedBox(),
                          icon: const Icon(Icons.arrow_drop_down),
                          isExpanded: true,
                          items: [
                          ],
                          onChanged: (value) {
                          },
                          hint: Text(
                            'Select',
                            style: TextStyle(color: Colors.grey[700]),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 20,),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: MaterialButton(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                        minWidth: double.infinity,
                        height: 50,
                        color: primaryColor,
                        onPressed: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context)=>const SearchPage()));
                        },
                        child: const Text(
                          "Search",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 17,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 20,),
                    const Center(child: Text("Switch to Advanced Search",style: TextStyle(fontSize: 16,color: primaryColor))),
                    const SizedBox(height: 20,)
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
