import 'package:eat_user_app/constant.dart';
import 'package:flutter/material.dart';

import 'HomePage.dart';


class bottomNavigationBar extends StatefulWidget {
  @override
  State<bottomNavigationBar> createState() => _bottomNavigationBarState();
}

class _bottomNavigationBarState extends State<bottomNavigationBar> {
  int myIndex = 0;
  Color color=kPrimaryColor;
  final List<Widget> tabs = [
    HomePage(),
    HomePage(),
    HomePage(),
    HomePage(),
    HomePage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFffffff),
      body: tabs[myIndex],
      bottomNavigationBar: BottomNavigationBar(
        onTap: (index) {
          setState(() {
            myIndex = index;
          });
        },
        currentIndex: myIndex,
        selectedItemColor: kPrimaryColor,
        unselectedItemColor: Colors.grey[600],
        selectedFontSize: 15,
        unselectedFontSize: 15,
        showUnselectedLabels: true,
        iconSize: 26,
        elevation: 0,
        backgroundColor: Color(0xFFffffff),
        type: BottomNavigationBarType.fixed,
        items: [
          BottomNavigationBarItem(
            icon: Icon(myIndex == 0 ? Icons.play_circle :Icons.play_circle_outline, size: 25,
              color: myIndex == 0 ? color : Colors.grey[600],),
            label: 'Reels',
          ),
          BottomNavigationBarItem(
            icon: Icon(myIndex == 1 ?Icons.production_quantity_limits:Icons.production_quantity_limits, size: 25,
              color: myIndex == 1 ? color:Colors.grey[600]),
            label: 'Products',
          ),
          BottomNavigationBarItem(
            icon: Icon(myIndex == 2 ?Icons.home:Icons.home_outlined, size: 25,
              color: myIndex == 2 ?color : Colors.grey[600],),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(myIndex == 3 ?Icons.library_books:Icons.library_books_outlined, size: 25,
              color: myIndex == 3 ? color : Colors.grey[600]),
            label: 'Party Order',
          ),
          BottomNavigationBarItem(
            icon: Icon(myIndex == 4 ?Icons.shopping_cart:Icons.shopping_cart_outlined, size: 25,
              color: myIndex == 4 ? color : Colors.grey[600]),
            label: 'Orders',
          ),
        ],
      ),
    );
  }
}