import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_controller.dart';
import 'package:carousel_slider/carousel_slider.dart';

import '../constant.dart';
import 'HomeScreenWidgets/loactionand.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with SingleTickerProviderStateMixin {
  late TabController tabController = TabController(length: 5, vsync: this);
  int currentindex = 0;
  List<String> appSliderImages = [
    'assets/images/delicious.jpg',
    'assets/images/food.jpg',
    'assets/images/delicious.jpg',
    'assets/images/delicious.jpg',
    'assets/images/food.jpg',
    'assets/images/delicious.jpg',
  ];
  List<String> tabs = [
    "Popular",
    "Most Visited",
    "Recent",
    "Explore",
  ];
  List<String> foodtime = ['Breakfast', 'Lunch', 'Snacks', 'Dinner', 'Beverage'];
  List<String> foodtype = ['Pure Veg', 'Non Veg', 'Hot sales',];
  CarouselController _carouselController = CarouselController();

  void startAutoPlay() {
    Future.delayed(const Duration(seconds: 3), () {
      if (_carouselController != null) {
        if (currentindex < appSliderImages.length - 1) {
          currentindex++;
        } else {
          currentindex = 0;
        }
        _carouselController.animateToPage(currentindex);
        startAutoPlay();
      }
    });
  }
  @override
  void initState() {
    super.initState();
    tabController = TabController(length: 5, vsync: this);
    //pageController = PageController();
  }

  @override
  void dispose() {
    tabController.dispose();
   // pageController.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    Color color = kPrimaryColor;

    return SafeArea(
      child: Scaffold(
        backgroundColor: Color(0xFFffffff),
        body: SingleChildScrollView(
          child: Column(
            children: [
              location(),
              thiruvalluvartext(size: size),
              SizedBox(height: 7,),
              searchbox(),
              SizedBox(height: 10),
              Padding(
                padding: const EdgeInsets.all(15),
                child: SizedBox(
                  height: size.height * 0.18,
                  width: MediaQuery.of(context).size.width,
                  child: CarouselSlider.builder(
                    itemCount: appSliderImages.length,
                    itemBuilder: (context, index, realIndex) {
                      return Container(
                        width: MediaQuery.of(context).size.width,
                        margin: const EdgeInsets.symmetric(
                          horizontal: 10,
                        ),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          image: DecorationImage(
                            image: AssetImage(appSliderImages[index]),
                            fit: BoxFit.cover,
                          ),
                        ),
                      );
                    },
                    options: CarouselOptions(
                      autoPlayInterval: Duration(seconds: 3),
                      autoPlay: true,
                      onPageChanged: (index, reason) {
                        currentindex = index;
                        setState(() {});
                      },
                    ),
                  ),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: appSliderImages.asMap().entries.map((entry) {
                  int index = entry.key;
                  return Container(
                    width: 6.0,
                    height: 6.0,
                    margin: EdgeInsets.symmetric(
                      vertical: 10.0,
                      horizontal: 5.0,
                    ),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: currentindex == index
                          ? Colors.green
                          : Colors.grey.shade400,
                    ),
                  );
                }).toList(),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Center(
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Expanded(
                        child: Container(
                          height: 0.5,
                          color: Colors.grey,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8),
                        child: Text(
                          'PRODUCTS',
                          style: TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.5,
                              color: Colors.black),
                        ),
                      ),
                      Expanded(
                        child: Container(
                          height: 0.5,
                          color: Colors.grey,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                child: Container(
                  height: size.height * 0.08,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: 5,
                    itemBuilder: (BuildContext context, int index) {
                      return Container(
                        width: size.width * 0.25,
                        margin: EdgeInsets.symmetric(horizontal: 5),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [Colors.lightGreen, Colors.green],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Center(
                          child: Text(
                            'Products ${index + 1}',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  buildContainer(context, 'Pure Veg', size,(){}),
                  buildContainer(context, 'Non Veg', size,(){}),
                  buildContainer(context, 'Hot Sales', size,(){}),
                ],
              ),
              SizedBox(
                height: 10,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: ExpansionTile(
                    iconColor: kPrimaryColor,
                    collapsedBackgroundColor: Colors.grey.shade200,
                    title: Text(
                      'Pre-Booking',
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: Colors.black),
                    ),
                    tilePadding: EdgeInsets.symmetric(horizontal: 10),
                    children: [
                      Padding(
                        padding: EdgeInsets.all(0),
                        child: Container(
                          height: size.height * 0.24,
                          child: ListView.builder(
                            physics: BouncingScrollPhysics(),
                            scrollDirection: Axis.horizontal,
                            itemCount: 5,
                            itemBuilder: (BuildContext context, int index) {
                              return Container(
                                width: size.width * 0.4,
                                margin: EdgeInsets.symmetric(horizontal: 5),
                                decoration: BoxDecoration(
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.grey.withOpacity(0.3),
                                      spreadRadius: 1,
                                      blurRadius: 4,
                                      offset: Offset(0, 1),
                                    ),
                                  ],
                                  color: Colors.white,
                                  gradient: LinearGradient(
                                    colors: [Colors.red.withOpacity(0.1), Colors.yellow.withOpacity(0.1)],
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                  ),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Column(
                                  children: [
                                    Container(
                                      margin: EdgeInsets.all(5),
                                      height: size.height * 0.12,
                                      decoration: BoxDecoration(
                                          borderRadius: BorderRadius.only(
                                            topLeft: Radius.circular(10),
                                            topRight: Radius.circular(10),
                                          ),
                                          image: DecorationImage(
                                              image: AssetImage(
                                                  'assets/images/food.jpg'))),
                                    ),
                                    Text('Bonda'),
                                    Text('Abi kitchen'),
                                    Text('Chennai'),
                                  ],
                                ),
                              );
                            },
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 10),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child: TabBar(
                    controller: tabController,
                    isScrollable: true,
                    tabs: foodtime.map((String tab) {
                      return Tab(
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            SizedBox(width: 8),
                            Text(tab),
                          ],
                        ),
                      );
                    }).toList(),
                    onTap: (value){
                      currentindex=value;
                    },
                    labelColor: Colors.black,
                    unselectedLabelColor: Colors.grey,
                    indicatorColor: Colors.black,
                    indicatorSize: TabBarIndicatorSize.tab,
                    indicatorWeight: 3.0,
                    labelStyle: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                    unselectedLabelStyle: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 700,
                child: ListView.builder(
                  physics: BouncingScrollPhysics(),
                  itemCount: 5,
                  itemBuilder: (BuildContext context, int index) {
                    return  Container(
                      child: TabBarView(
                        controller: tabController,
                        children: [
                          Tab(
                            child: Center(child: Text('Breakfast ')),
                          ),
                          Tab(
                            child: Center(child: Text('Lunch $index')),
                          ),
                          Tab(
                            child: Center(child: Text('Snacks $index')),
                          ),
                          Tab(
                            child: Center(child: Text('Dinner $index')),
                          ),
                          Tab(
                            child: Center(child: Text('Beverage $index')),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),

            ],
          ),
        ),
      ),
    );
  }
}


Widget buildContainer(BuildContext context, String foodtype, Size size,VoidCallback? onPressed) {
  int currentindex = 0;
  return Padding(
    padding: const EdgeInsets.symmetric(horizontal: 10),
    child: GestureDetector(
      onTap: onPressed,
      child: Container(
        width: size.width * 0.265,
        height: size.height * 0.040,
        margin: EdgeInsets.symmetric(horizontal: 4),
        decoration: BoxDecoration(
          color: currentindex==0?Colors.white:Colors.black,
          boxShadow: [
            BoxShadow(
              color: kPrimaryColor.withOpacity(0.3),
              spreadRadius: 1,
              blurRadius: 4,
              offset: Offset(0, 1),
            ),
          ],
          border: Border.all(width: 0.5, color: Colors.black.withOpacity(0.5)),
          borderRadius: BorderRadius.circular(5),
        ),
        child: Center(
          child: Text(
            foodtype,
            style: TextStyle(
              color: Colors.black,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    ),
  );
}

Widget foodtimings(BuildContext context, String foodtiming, Size size,VoidCallback? onPressed) {
  return Padding(
    padding: const EdgeInsets.symmetric(horizontal: 10),
    child: GestureDetector(
      onTap: onPressed,
      child: Container(
        height: size.height * 0.045,
        margin: EdgeInsets.symmetric(horizontal: 4),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: kPrimaryColor.withOpacity(0.3),
              spreadRadius: 1,
              blurRadius: 4,
              offset: Offset(0, 1),
            ),
          ],
          border: Border.all(width: 0.5, color: Colors.black.withOpacity(0.5)),
          borderRadius: BorderRadius.circular(5),
        ),
        child: Center(
          child: Text(
            foodtiming,
            style: TextStyle(
              color: Colors.black,
              fontWeight: FontWeight.bold,
              fontSize: 8,
              // Add other style properties as needed
            ),
          ),
        ),
      ),
    ),
  );
}
