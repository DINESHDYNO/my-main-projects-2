import 'package:flutter/material.dart';

import '../../constant/Constant.dart';

class PartnerPreference extends StatelessWidget {
  const PartnerPreference({super.key});

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return SafeArea(
      child: Scaffold(
        floatingActionButton: Container(
          margin: const EdgeInsets.symmetric(horizontal: 10),
          height: 70,
          width: size.width,
          padding: const EdgeInsets.all(10),
          child: FloatingActionButton(
            backgroundColor: primaryColor,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            onPressed: () {},
            child: const Text("Save Changes", style: TextStyle(fontSize: 15, fontWeight: FontWeight.w500)),
          ),
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
        appBar: PreferredSize(
          preferredSize: const Size.fromHeight(64),
          child: AppBar(
            elevation: 0,
            backgroundColor: Colors.white,
            leading: InkWell(
              onTap: () {
                Navigator.pop(context);
              },
              child: Image.asset("assets/images/38.png", color: Colors.black, scale: 3),
            ),
            title: const Text(
              "Partner Preference",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black),
            ),
          ),
        ),
        body: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          children: [
            const SizedBox(height: 20),
            buildDropdown("Marital Status", "Unmarried", size),
            const SizedBox(height: 20),
            buildRangeDropdown("Age From", "To", size,[
            '19', '21','22', '23','24', '25','26', '27',
            ],'Select'),
            const SizedBox(height: 20),
            buildRangeDropdown("Height From", "To", size,[
              '19', '21','22', '23','24', '25','26', '27',
            ],'Select'),
            const SizedBox(height: 20),
            buildDropdown("Physical Status", "Unmarried", size),
            const SizedBox(height: 20,),
            const Text("Cultural Background", style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
            const SizedBox(height: 20,),
            buildRangeDropdown("Mother Tongue", "Religion", size,[
              'Tamil','English'
            ],'Select'),
            const SizedBox(height: 20),
            buildRangeDropdown("Caste", "Religion", size,[
              'Tamil','English'
            ],'Select'),
            const SizedBox(height: 20),
            buildDropdown("Education", "Unmarried", size),
            const SizedBox(height: 20),
            buildDropdown("Occupation", "Unmarried", size),
            const SizedBox(height: 20),
            const Text("Location", style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
            const SizedBox(height: 20,),
            buildRangeDropdown("Country", "Lifestyle - Habits", size,[
              'Tamil','English'
            ],'Select'),
            const SizedBox(height: 20),
            buildRangeDropdown("Smoking Habits", "Drinking Habits", size,[
              'Tamil','English'
            ],'Select'),
            const SizedBox(height: 20),
            buildDropdown("Monthly Income", "Unmarried", size),
            const SizedBox(height: 20),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'About My Partner',
                  style: TextStyle(
                      color: primaryColor,fontSize: 15),
                ),
                const SizedBox(
                  height: 10,
                ),
                Container(
                  padding: const EdgeInsets.all(10),
                  margin: const EdgeInsets.symmetric(),
                  height: 144,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.grey.withOpacity(0.1)
                  ),child: TextFormField(
                  decoration:  InputDecoration(
                      contentPadding: const EdgeInsets.all(10),
                      hintText: "Write About your Partner...",
                      hintStyle: TextStyle(color: const Color(0xff080808).withOpacity(0.5,),fontSize: 16),
                      border: InputBorder.none
                  ),
                  minLines: 3,
                  maxLines: 5,

                ),
                ),
                const SizedBox(height: 20,)
              ],
            ),
            const SizedBox(height: 100),
          ],
        ),
      ),
    );
  }

  Widget buildDropdown(String label, String initialValue, Size size) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(color: primaryColor, fontSize: 15),
        ),
        const SizedBox(height: 10),
        Container(
          height: 60,
          width: size.width,
          decoration: BoxDecoration(
            color: Colors.grey.withOpacity(0.15),
            borderRadius: BorderRadius.circular(15),
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
            child: DropdownButton(
              underline: const SizedBox(),
              icon: const Icon(Icons.arrow_drop_down),
              isExpanded: true,
              items: const [
                DropdownMenuItem(value: "Unmarried", child: Text("Unmarried")),
                DropdownMenuItem(value: "Married", child: Text("Married")),
                // Add more items as needed
              ],
              onChanged: (value) {},
              value: initialValue,
            ),
          ),
        ),
      ],
    );
  }

  Widget buildRangeDropdown(String label, String toLabel, Size size, List<String> items, String initialValue) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '$label',
              style: const TextStyle(color: primaryColor, fontSize: 15),
            ),
            const SizedBox(height: 10),
            Container(
              height: 60,
              width: size.width / 2.5,
              decoration: BoxDecoration(
                color: Colors.grey.withOpacity(0.15),
                borderRadius: BorderRadius.circular(15),
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                child: DropdownButton(
                  underline: const SizedBox(),
                  icon: const Icon(Icons.arrow_drop_down),
                  isExpanded: true,
                  items: items.map((String value) {
                    return DropdownMenuItem(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                  onChanged: (value) {},
                  hint: Text(initialValue, style: TextStyle(color: Colors.grey[700])),
                ),
              ),
            ),
          ],
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              toLabel,
              style: const TextStyle(color: primaryColor, fontSize: 15),
            ),
            const SizedBox(height: 10),
            Container(
              height: 60,
              width: size.width / 2.5,
              decoration: BoxDecoration(
                color: Colors.grey.withOpacity(0.15),
                borderRadius: BorderRadius.circular(15),
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                child: DropdownButton(
                  underline: const SizedBox(),
                  icon: const Icon(Icons.arrow_drop_down),
                  isExpanded: true,
                  items: items.map((String value) {
                    return DropdownMenuItem(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                  onChanged: (value) {},
                  hint: Text(initialValue, style: TextStyle(color: Colors.grey[700])),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}
