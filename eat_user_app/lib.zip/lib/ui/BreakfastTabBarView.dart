import 'package:flutter/material.dart';
class Breakfast extends StatefulWidget {
  const Breakfast({super.key});

  @override
  State<Breakfast> createState() => _BreakfastState();
}

class _BreakfastState extends State<Breakfast> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
       Padding(
         padding: const EdgeInsets.symmetric(horizontal: 20),
         child: Text(
           'AVAILABLE KITCHENS NEAR YOU',
           style: TextStyle(
             fontSize: 16,
             fontWeight: FontWeight.w900,
             color: Colors.black,
           ),
         ),

       ),
       SizedBox(height: 100),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Text(
            'AVAILABLE KITCHENS NEAR YOU',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w900,
              color: Colors.black,
            ),
          ),

        ),
        SizedBox(height: 100),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Text(
            'AVAILABLE KITCHENS NEAR YOU',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w900,
              color: Colors.black,
            ),
          ),

        ),
        SizedBox(height: 100),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Text(
            'AVAILABLE KITCHENS NEAR YOU',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w900,
              color: Colors.black,
            ),
          ),

        ),
        SizedBox(height: 100),

       /*ListView.builder(
         shrinkWrap: true,
         physics: NeverScrollableScrollPhysics(),
         itemCount: 5,
         itemBuilder: (BuildContext context, int index) {
           return AvailableKitchen(
             color: Colors.black,
             foodimage: '',
             title: 'Kitchen Title',
             price: '100',
             location: 'Kitchen Location',
           );
         },
       ),*/
      ],
    );

  }
}
