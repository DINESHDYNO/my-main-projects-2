import 'package:flutter/material.dart';


const kPrimaryColor = Color(0xFF066839);
const kSecondaryColor = Color(0xff94fbbf);
const kGrayColor = Color(0xfff6f6f6);
const kWhiteColor = Color(0xffffffff);
const kTextGrayColor = Color(0xff262626);