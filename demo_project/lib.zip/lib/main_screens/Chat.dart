import 'package:flutter/material.dart';

import '../chat_page_screens/MainChatingPage.dart';



class ChatPage extends StatelessWidget {
  const ChatPage({super.key});

  @override
  Widget build(BuildContext context) {

    Size size=MediaQuery.of(context).size;
    return SafeArea(
      child: Scaffold(
        backgroundColor: const Color(0xFFFFF9F0),
        body: ListView(
          children: [
            Container(
              padding: EdgeInsets.symmetric(horizontal: 20),
              height: 64,
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.18),
                    spreadRadius: 1,
                    blurRadius: 4,
                    offset: const Offset(3, 3),
                  ),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 7.5),
                        child: Text(
                          'Message',
                          style: TextStyle(
                            fontWeight: FontWeight.w700,
                            color: Colors.black,
                            fontSize: 24,
                          ),
                        ),
                      ),
                    ],
                  ),
                  Image.asset('assets/images/17.png', scale: 3),
                ],
              ),
            ),

            ChatItemWidget(chat:(){
               Navigator.push(context, MaterialPageRoute(builder: (context)=>ChattingPage()));
             },name: 'Dhana lashmi', message: 'Today I work in a cafe. Come there, I’ll buy you…', time: '13:25 PM', unreadCount: 3, image:  "assets/images/69.png",),
             ChatItemWidget(chat:(){
               Navigator.push(context, MaterialPageRoute(builder: (context)=>ChattingPage()));
             },name: 'Dhana lashmi', message: 'Do you want to hear a joke about Chandler?', time: '13:25 PM', unreadCount: 5, image:  "assets/images/70.png",),
             ChatItemWidget(chat:(){
               Navigator.push(context, MaterialPageRoute(builder: (context)=>ChattingPage()));
             },name: 'Dhana lashmi', message: 'We’re all coming to this party. I guess you shouldn’t have found out about this.', time: '13:25 PM', unreadCount: 1, image:  "assets/images/71.png",),
             ChatItemWidget(chat:(){
               Navigator.push(context, MaterialPageRoute(builder: (context)=>ChattingPage()));
             },name: 'Dhana lashmi', message: 'Do you want to hear a joke about Joey?', time: '13:25 PM', unreadCount: 9, image:  "assets/images/72.png",),
             ChatItemWidget(chat:(){
               Navigator.push(context, MaterialPageRoute(builder: (context)=>ChattingPage()));
             },name: 'Dhana lashmi', message: 'I heard that you are getting married. Congr. …', time: '13:25 PM', unreadCount: 0, image:  "assets/images/76.png",),
          ],
        ),
      ),
    );
  }
}


class ChatItemWidget extends StatelessWidget {
  const ChatItemWidget({
    Key? key,
    required this.chat,
    required this.image,
    required this.name,
    required this.message,
    required this.time,
    required this.unreadCount,
  }) : super(key: key);
  final VoidCallback chat;
  final String image;
  final String name;
  final String message;
  final String time;
  final int unreadCount;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
      child: InkWell(
        onTap: chat,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              height: 70,
              width: 70,
              child: Stack(
                children: [
                  Positioned.fill(
                    child: ClipOval(
                      child: Image.asset(
                        image,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  if (unreadCount > 0)
                    Positioned(
                      bottom: 0,
                      right: 0,
                      child: Container(
                        width: 10,
                        height: 10,
                        decoration: const BoxDecoration(
                          color: Colors.green,
                          shape: BoxShape.circle,
                        ),
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    overflow: TextOverflow.ellipsis,
                    maxLines: 1,
                  ),
                  const SizedBox(height: 5),
                  Text(
                    message,
                    style: const TextStyle(fontSize: 14, color: Color(0xFF8D8D8D)),
                    overflow: TextOverflow.ellipsis,
                    maxLines: 2,
                  ),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  time,
                  style: const TextStyle(fontSize: 14, color: Color(0xFF8D8D8D)),
                ),
                const SizedBox(height: 5),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.red,
                    borderRadius: BorderRadius.circular(50),
                  ),
                  child: Text(
                    unreadCount.toString(),
                    style: const TextStyle(color: Colors.white),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

