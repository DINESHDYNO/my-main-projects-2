import 'package:flutter/material.dart';

import '../../constant.dart';



class location extends StatefulWidget {
  const location({super.key});

  @override
  State<location> createState() => _locationState();
}

class _locationState extends State<location> {
  @override
  Widget build(BuildContext context) {
    Color color = kPrimaryColor;
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 10,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Container(
                height: 32,
                width: 32,
                decoration: BoxDecoration(
                  color: color,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Icon(
                  Icons.location_on,
                  color: Colors.white,
                ),
              ),
              SizedBox(
                width: 10,
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        'West Mambalam',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 17,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Icon(
                        Icons.keyboard_arrow_down_outlined,
                        color: kPrimaryColor,
                      )
                    ],
                  ),
                  Text(
                    'Lake View Road,West Mambalam,Chennai....',
                    maxLines: 3,
                    style: TextStyle(
                      color: Colors.grey[700],
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ],
          ),
          Container(
            height: 32,
            width: 32,
            decoration: BoxDecoration(
              color: color, // Use the same color as above
              borderRadius: BorderRadius.circular(20),
            ),
            child: Icon(
              Icons.person_2_outlined,
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }
}
class thiruvalluvartext extends StatelessWidget {
  const thiruvalluvartext({
    super.key,
    required this.size,
  });

  final Size size;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Image.asset(
            'assets/images/thiruvalluvar.png',
            height: 50,
            width: 50,
          ),
          SizedBox(
            width: 10,
          ),
          Expanded(
            child: Container(
              width: size.width * 0.65,
              margin: EdgeInsets.all(10),
              child: Text(
                "அகர முதல எழுத்தெல்லாம் ஆதி \nபகவன் முதற்றே உலகு...",
                style: TextStyle(
                  wordSpacing: 2,
                  letterSpacing: 0.5,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  fontSize: 12,
                ),
                maxLines: 2,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
class searchbox extends StatelessWidget {
  const searchbox({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: Container(
        height: 50,
        decoration: BoxDecoration(
          color: Color(0xFFffffff),
          borderRadius: BorderRadius.circular(10),
          boxShadow: [
            BoxShadow(
              color: kPrimaryColor.withOpacity(0.3),
              spreadRadius: 1,
              blurRadius: 4,
              offset: Offset(0, 1),
            ),
          ],
        ),
        child: TextFormField(
          decoration: InputDecoration(
            prefixIcon: Icon(Icons.search_outlined, color: kPrimaryColor),
            suffixIcon: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(
                      vertical: 10, horizontal: 5),
                  child: Container(
                    height: 40,
                    child: VerticalDivider(
                      width: 5,
                      thickness: 1,
                      color: Colors.grey,
                    ),
                  ),
                ),
                Icon(Icons.filter_alt_sharp, color: kPrimaryColor),
              ],
            ),
            hintText: 'Search favorite item....',
            hintStyle: TextStyle(
              color: Colors.grey,
              fontSize: 14,
              fontWeight: FontWeight.w400,
            ),
            border: InputBorder.none,
            focusedBorder: InputBorder.none,
          ),
          textAlign: TextAlign.start,
        ),
      ),
    );
  }
}