

import 'package:demo_project/constant/Constant.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../BottomBar/bottomNavigation.dart';


class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  String? selectedOption='Male';
  String selectDate='';
  String _selectedItem = 'Self'; // Default selected item
  bool _isChecked=false;
  final List<String> _dropdownItems = [
    'Self',
    'Other',
  ];
  final List<String> _dropdownItems1 = [
    'Male',
    'Female',
  ];

  final TextEditingController _dateController = TextEditingController();

  @override
  void dispose() {
    _dateController;
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    Size size=MediaQuery.of(context).size;
    return Scaffold(
      body: ListView(
        children: [
          Container(
            height: size.height * 0.25,
            width: size.width,
            decoration: const BoxDecoration(
                image: DecorationImage(
                    image: AssetImage('assets/images/5.png'),
                    fit: BoxFit.fill)),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Center(
                  child: Image.asset('assets/images/6.png'),
                ),
                const Text('Create your Account',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 24),)
              ],
            ),
          ),
          const SizedBox(height: 20,),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("On behalf",style: TextStyle(fontSize: 15,color: primaryColor,),),
                const SizedBox(height: 10,),
                Container(
                 padding: const EdgeInsets.only(top: 5),
                  height: 60,
                  width: size.width,
                  decoration: BoxDecoration(
                      color: Colors.grey.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(15)
                  ),child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: DropdownButton<String>(
                      elevation: 0,
                      icon: const Icon(Icons.arrow_drop_down),
                      isExpanded: true,
                      underline: SizedBox(),
                      value: _selectedItem,
                      items: _dropdownItems.map((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(value),
                        );
                      }).toList(),
                      onChanged: (String? newValue) {
                        setState(() {
                          _selectedItem = newValue!;
                        });
                      },
                    ),
                  ),
                )
              ],
            ),
          ),
          const SizedBox(height: 20,),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("First Name",style: TextStyle(fontSize: 15,color: primaryColor),),
                const SizedBox(height: 10,),
                Container(
                  height: 60,
                  width: size.width,
                  decoration: BoxDecoration(
                      color: Colors.grey.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(15)
                  ),child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 5),
                    child: ListTile(
                      title: TextFormField(
                        decoration: const InputDecoration(
                            hintText: "Enter Your First Name",
                            border: InputBorder.none
                        ),
                      ),
                    )
                ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20,),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Last Name",style: TextStyle(fontSize: 15,color:primaryColor),),
                const SizedBox(height: 10,),
                Container(
                  height: 60,
                  width: size.width,
                  decoration: BoxDecoration(
                      color: Colors.grey.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(15)
                  ),child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 5),
                    child: ListTile(
                      title: TextFormField(
                        decoration: const InputDecoration(
                            hintText: "Enter Your Last Name",
                            border: InputBorder.none
                        ),
                      ),
                    )
                ),
                )
              ],
            ),
          ),
          const SizedBox(height: 20,),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Gender",style: TextStyle(fontSize: 15,color: primaryColor),),
                const SizedBox(height: 10,),
                Container(
                  padding: const EdgeInsets.only(top: 5),
                  height: 60,
                  width: size.width,
                  decoration: BoxDecoration(
                      color: Colors.grey.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(15)
                  ),child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child:DropdownButton<String>(
                    icon: const Icon(Icons.arrow_drop_down),
                    isExpanded: true,
                    value: selectedOption,
                      underline: SizedBox(),
                    items: _dropdownItems1.map((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(value),
                      );
                    }).toList(),
                    onChanged: (String? newValue) {
                      setState(() {
                        selectedOption = newValue!;
                      });
                    },
                  ),
                ),
                )
              ],
            ),
          ),
          const SizedBox(height: 20,),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Date of Birth", style: TextStyle(fontSize: 15, color: primaryColor),),
                const SizedBox(height: 10,),
                Container(
                  height: 60,
                  width: size.width,
                  decoration: BoxDecoration(
                    color: Colors.grey.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.only(left: 5),
                    child: ListTile(
                      title: TextFormField(
                        controller: _dateController,
                        readOnly: true,
                        enableInteractiveSelection: false,
                        onTap: () async {
                          final DateTime? pickedDate = await showDatePicker(
                            context: context,
                            initialDate: DateTime.now(),
                            firstDate: DateTime(1900),
                            lastDate: DateTime(2100),
                          );
                          if (pickedDate != null) {
                            _dateController.text = DateFormat('dd MMM yyyy').format(pickedDate);
                            print(pickedDate);
                          }
                        },
                        decoration: const InputDecoration(
                          hintText: "Select Your Date of Birth",
                          border: InputBorder.none,
                        ),
                      ),
                      trailing: InkWell(
                        onTap: () async {
                          final DateTime? pickedDate = await showDatePicker(
                            context: context,
                            initialDate: DateTime.now(),
                            firstDate: DateTime(1900),
                            lastDate: DateTime(2100),
                          );
                          if (pickedDate != null) {
                            _dateController.text = DateFormat('dd MMM yyyy').format(pickedDate);
                            print(pickedDate);
                          }
                        },
                        child: Image.asset("assets/images/15.png", scale: 2.5),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20,),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Email",style: TextStyle(fontSize: 15,color:primaryColor),),
                const SizedBox(height: 10,),
                Container(
                  height: 60,
                  width: size.width,
                  decoration: BoxDecoration(
                      color: Colors.grey.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(15)
                  ),child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 5),
                    child: ListTile(
                      title: TextFormField(
                        decoration: const InputDecoration(
                            hintText: "Enter your Email",
                            border: InputBorder.none
                        ),
                      ),
                    )
                ),
                ),
                const SizedBox(height: 10,),
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Text('Use Phone Number',style: TextStyle(fontSize: 15,color: primaryColor, decoration: TextDecoration.underline,),)
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20,),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Password",style: TextStyle(fontSize: 15,color: primaryColor),),
                const SizedBox(height: 10,),
                Container(
                  height: 60,
                  width: size.width,
                  decoration: BoxDecoration(
                      color: Colors.grey.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(15)
                  ),child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 5),
                    child: ListTile(
                      title: TextFormField(
                        decoration: const InputDecoration(
                            hintText: "Password",
                            border: InputBorder.none
                        ),
                      ),
                    )
                ),
                )
              ],
            ),
          ),
          const SizedBox(height: 20,),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Confirm Password",style: TextStyle(fontSize: 15,color: primaryColor),),
                const SizedBox(height: 10,),
                Container(
                  height: 60,
                  width: size.width,
                  decoration: BoxDecoration(
                      color: Colors.grey.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(15)
                  ),child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 5),
                    child: ListTile(
                      title: TextFormField(
                        decoration: const InputDecoration(
                            hintText: "Confirm Password",
                            border: InputBorder.none
                        ),
                      ),
                    )
                ),
                )
              ],
            ),
          ),
          const SizedBox(height: 20,),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Refer Code",style: TextStyle(fontSize: 15,color: primaryColor),),
                const SizedBox(height: 10,),
                Container(
                  height: 60,
                  width: size.width,
                  decoration: BoxDecoration(
                      color: Colors.grey.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(15)
                  ),child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 5),
                    child: ListTile(
                      title: TextFormField(
                        decoration: const InputDecoration(
                            hintText: "Type your refer Code",
                            border: InputBorder.none
                        ),
                      ),
                    )
                ),
                )
              ],
            ),
          ),
          const SizedBox(height: 20,),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Row(
              children: [
                Checkbox(
                  value: _isChecked,
                  onChanged: (bool? newValue) {
                    setState(() {
                      _isChecked = newValue ?? false;
                    });
                  },
                ),
                const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Text('I agree to the',style: TextStyle(color: Colors.black,fontSize: 14),),
                        SizedBox(width: 5,),
                        Text('Terms & Conditions',style: TextStyle(color: primaryColor,fontSize: 14),),
                        SizedBox(width: 5,),
                        Text('&',style: TextStyle(color: Colors.black,fontSize: 14),),
                      ],
                    ),
                    Text("Privacy Policy",style: TextStyle(color: primaryColor),),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 20,),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: MaterialButton(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
              ),
              minWidth: double.infinity,
              height: 50,
              color: primaryColor,
              onPressed: () {
                Navigator.push(context,MaterialPageRoute(builder: (context)=>const HomeBottomNavigationScreen()));
              },
              child: const Text(
                "Sign Up",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
          const SizedBox(height: 20,),
        ],
      ),
    );
  }
}
