import 'package:flutter/material.dart';

import '../constant/Constant.dart';
import '../main_screens/Chat.dart';
import '../main_screens/Explore.dart';
import '../main_screens/Member.dart';
import '../main_screens/Profile.dart';

class HomeBottomNavigationScreen extends StatefulWidget {
  const HomeBottomNavigationScreen({Key? key}) : super(key: key);

  @override
  _HomeBottomNavigationScreenState createState() =>
      _HomeBottomNavigationScreenState();
}

class _HomeBottomNavigationScreenState
    extends State<HomeBottomNavigationScreen> {
  final List<Widget> _children = [
    const MemberPage(),
    const ExplorePage(),
    const ChatPage(),
    const ProfilePage(),
  ];

  int selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    final labelTextStyle =
    Theme.of(context).textTheme.subtitle2!.copyWith(fontSize: 14.0,fontWeight: FontWeight.w500);
    return Scaffold(
      body: _children[selectedIndex],
      bottomNavigationBar: SizedBox(
        height: 75.0,
        child: BottomNavigationBar(
          backgroundColor: Colors.white,
          type: BottomNavigationBarType.fixed,
          selectedItemColor: primaryColor,
         // unselectedItemColor: Colors.grey,
          currentIndex: selectedIndex,
          selectedLabelStyle: labelTextStyle,
          unselectedLabelStyle: labelTextStyle,
          onTap: (index) {
            setState(() {
              selectedIndex = index;
            });
          },
          items:  [
            BottomNavigationBarItem(
              icon: Image.asset('assets/images/27.png',scale: 3,color: selectedIndex==0?primaryColor:const Color(0xff8D8D8D),),
              label: 'Members',
            ),
            BottomNavigationBarItem(
              icon: Image.asset('assets/images/28.png',scale: 3,color: selectedIndex==1?primaryColor:const Color(0xff8D8D8D),),
              label: 'Explore',
            ),
            BottomNavigationBarItem(
              icon: Image.asset('assets/images/29.png',scale: 3,color: selectedIndex==2?primaryColor:const Color(0xff8D8D8D),),
              label: 'Chat',
            ),
            BottomNavigationBarItem(
              icon: Image.asset('assets/images/30.png',scale: 3,color: selectedIndex==3?primaryColor:const Color(0xff8D8D8D)),
              label: 'Profile',
            ),
          ],
        ),
      ),
    );
  }
}
