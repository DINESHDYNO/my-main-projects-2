import 'package:flutter/material.dart';


class Blogs extends StatelessWidget {
  const Blogs({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(

    );
  }
}
